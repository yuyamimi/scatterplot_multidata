/**
 * 
 */
/**
 * @author matsuomikage
 *
 */
module SPSelection {
	requires java.desktop;
}