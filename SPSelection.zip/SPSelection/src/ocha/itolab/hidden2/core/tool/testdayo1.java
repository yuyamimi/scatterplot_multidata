package ocha.itolab.hidden2.core.tool;

public class testdayo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
