package ocha.itolab.hidden2.core.tool;

public class DimensionPair {
	int id, id1, id2;
	double r;
	double[] score = new double[4];
}
