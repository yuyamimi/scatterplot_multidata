package ocha.itolab.hidden2.datagen.youtuber;

public class YouTuber {
	int date, nummovie, numfan, maxplay, instagram, twitter, tiktok,
		subchannel, member, office, gender, numperson, professional;
	double frequency;
	long totalplay;
	String name;
}
