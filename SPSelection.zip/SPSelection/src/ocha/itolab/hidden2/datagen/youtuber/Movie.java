package ocha.itolab.hidden2.datagen.youtuber;

public class Movie {
	int length, date, numplay, higheval, loweval, comments,
		hashtags, colab, gender, numperson, professional;
	String name, youtuber, url;	
}
