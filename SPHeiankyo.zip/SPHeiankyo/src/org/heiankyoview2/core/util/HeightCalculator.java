package org.heiankyoview2.core.util;

public interface HeightCalculator {

	public double calculate(float value);
}
