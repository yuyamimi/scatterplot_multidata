package org.heiankyoview2.core.util;

import java.awt.Color;

public interface ColorCalculator {

	public Color calculate(float value);
	
}
