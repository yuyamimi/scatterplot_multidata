module SPHeiankyo {
	  requires java.desktop;
}