package ocha.itolab.hidden2.core.tool;

public class DimensionPair {
	double[] score = new double[4];
	int id, id1, id2;
	double r;
}
